if(plateform == 0) then
    snake = {
        screen = {
            title = "Snake",
            width = 800,
            height = 800,
            framerate = 15
        },
        debugMode = false
    }
else
    snake = {
        screen = {
            title = "Snake",
            width = 320,
            height = 240,
            framerate = 15
        }
    }
end
