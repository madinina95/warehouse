-- default fonts available

fonts = {
    startedMessage = "======= Fonts manager started =======",
    fonts = {
        id = 0,
        path = "fonts/default/default.otf"
    }
}