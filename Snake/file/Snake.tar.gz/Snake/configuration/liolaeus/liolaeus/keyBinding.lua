-- Sfml key enum

dofile(configPath .. "include/sfmlKeyboardKey.lua")
dofile(configPath .. "include/sfmlJoystickKey.lua")
dofile(configPath .. "include/sfmlMouseKey.lua")

keybinding = {
    startedMessage = "======= Keybinding manager started ======="
}