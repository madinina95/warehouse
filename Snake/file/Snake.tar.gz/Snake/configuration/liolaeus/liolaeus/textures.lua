-- Default texture available

textures = {
    startedMessage = "======= Textures manager started =======",
    textures = {
        id = 0,
        path = "sprites/default/default.png"
    }
}