window = {
    startedMessage = "======= Window manager started ======="
}