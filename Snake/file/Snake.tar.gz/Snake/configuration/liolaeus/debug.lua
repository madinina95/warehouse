debugMode = {
    startedMessage = "======= Debug manager started =======",
    debugMode = true,
    showImguiDemo = false,
    assets = {
        play = {
            id = 1,
            path = "sprites/debugger/play.png"
        },
        pause = {
            id = 2,
            path = "sprites/debugger/pause.png"
        },
        stop = {
            id = 3,
            path = "sprites/debugger/stop.png"
        }
    }
}