
tileMap = {
    startedMessage = "======= TileMap manager started =======",
}