game = {
    startedMessage = "======= Game manager started ======="
}