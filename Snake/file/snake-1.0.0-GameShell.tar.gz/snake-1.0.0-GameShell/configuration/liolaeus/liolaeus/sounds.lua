-- default sounds available

sounds = {
    startedMessage = "======= Sounds manager started =======",
    sounds = {
            id = 0,
            path = "sounds/default/default.ogg"
    }
}