joystick = {
    axis = {
        X = 0, -- joystick gauche en X
        Y = 1, -- joystick gauche en Y
        Z = 2, -- L2
        R = 3, -- R2
        U = 4, -- joystick droit en X
        V = 5, -- joystick droit en Y
        PovX = 6, -- croix directionnelle en X
        PovY = 7 -- croix directionnelle en Y
    },
    buttons = {
        Square = 3,
        Cross = 0,
        Circle = 1,
        Triangle = 2,
        Ps = 10,
        Options = 9,
        Share = 8,
        L3 = 11,
        R3 = 12,
        L1 = 4,
        R1 = 5,
        L2 = 6,
        R2 = 7
    },
    event = {
        connected = 17,
        disconnected = 18
    }
}