scripts = {
    startedMessage = "[liolaeus] [info] ======== Scripts manager started =========="
}