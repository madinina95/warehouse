logger = {
    name = "liolaeus",
    level = 1,
    startedMessage = "======= Logger manager started =======",
    errorMessage = "Log initialization failed: ",
    async = {
        qSize = 128,
        threadCount = 1
    },
    console = {
        level = 1,
        pattern = "[liolaeus] [%^%l%$] %v"
    },
    file = {
        level = 2,
        name = "logs/liolaeus.log"
    }
}