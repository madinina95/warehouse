state = {
    startedMessage = "======= State manager started ======="
}