musics = {
    startedMessage = "======= Musics manager started =======",
    musics = {
        id = 0,
        path = "musics/default/default.ogg"
    }
}